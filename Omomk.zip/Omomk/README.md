Omock made by Uree1229  (https://github.com/Uree1229/Omomk)
-----------------------------------------------------------


**contents**

1. Game needs two player
2. black is first turn
3. timeout 20sec
4. Winner = five same color stones on a row
5.  can you miss so i give you chance to place check_stone
