Assignments of week 3 
====
RSTG made by Uree1229  (https://github.com/Uree1229/bangtal_Library)
----

**contents**
1. can test your Reaction Speed
2. success click one ball = +1 point
