Assignments of week 4
====
puzzleGame made by Uree1229  (https://github.com/Uree1229/bangtal-PuzzleGame)
----

**contents**
1. 3 kind of background 
2. timer : 360s
3. if you clear game, clear time is 
