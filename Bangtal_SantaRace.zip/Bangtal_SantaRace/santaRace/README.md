Assignments of week 3 
====
santaRace made by Uree1229  (https://github.com/Uree1229/bangtal_Library)
----

**contents**
1. move santa only use keybord (one press move 20)
2. timer : 30s
3. santa only move in x: 0 ~ 1280, y: 300 ~ 650
4. obstacle cloud :
  + random create(if you click start button, repeat)
  + can erase use mouse
  + if you can't erase, cloud block your sight
